// Flutter code to create the Omya Hacker app launcher
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:device_apps/device_apps.dart';

void main() {
  runApp(OmyaHackerApp());
}

class OmyaHackerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Omya Hacker',
      theme: ThemeData.dark(),
      home: OmyaHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class OmyaHomePage extends StatelessWidget {
  final String telegramUrl = 'https://t.me/omyahackerr';
  final String whatsappUrl = 'https://chat.whatsapp.com/GUHH1NevGOH9pkW8th2O4n';
  final String youtubeUrl = 'https://youtube.com/@omyahackerr01?si=uFl8WaS78UWNIenK';

  void _launchBGMI() async {
    bool isInstalled = await DeviceApps.isAppInstalled('com.pubg.imobile');
    if (isInstalled) {
      DeviceApps.openApp('com.pubg.imobile');
    } else {
      print("BGMI is not installed.");
    }
  }

  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      print("Could not launch \$url");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('Omya Hacker'),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 60,
                backgroundImage: AssetImage('assets/logo.jpg'),
              ),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: _launchBGMI,
                child: Text('Start BGMI'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => _launchURL(telegramUrl),
                child: Text('Join Telegram'),
              ),
              ElevatedButton(
                onPressed: () => _launchURL(whatsappUrl),
                child: Text('Join WhatsApp'),
              ),
              ElevatedButton(
                onPressed: () => _launchURL(youtubeUrl),
                child: Text('Visit YouTube'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
